/*
 * fact.h -- definicoes e declaracoes globais para o programa fact
 */

int factorial(int n);

